# Scrypted reolink videoclips

https://github.com/apocaliss92/scrypted-reolink-videoclips - For requests and bugs

This plugin allows reolink cameras to provide onboard stored videoclips, it's recommended to create a different user (non admin) and provide it in the settings of the plugin
